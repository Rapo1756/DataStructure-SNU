public class Station {
    public String id;
    public String name;
    public String line;

    public Station(String id, String stationName, String line) {
        name = stationName;
        this.line = line;
        this.id = id;
    }
}

